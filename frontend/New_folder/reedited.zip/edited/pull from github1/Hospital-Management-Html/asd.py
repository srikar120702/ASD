import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
import pickle
from sklearn.metrics import classification_report, confusion_matrix
import warnings

warnings.filterwarnings("ignore")

data = pd.read_csv("b.csv")
Y = data['Class/ASD Traits ']
X = data.drop(['Class/ASD Traits '], axis=1)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.30, random_state=7)
print('Processed....')

msvc = SVC()
msvc.fit(x_train, y_train)
pred = msvc.predict(x_test)

CMSVM = confusion_matrix(y_test, pred)
print(CMSVM)

CRSVM = classification_report(y_test, pred)
print(CRSVM)

# Corrected pickle.dump and pickle.load
with open('model.pkl', 'wb') as model_file:
    pickle.dump(msvc, model_file)

# Loading the model
with open('model.pkl', 'rb') as model_file:
    loaded_model = pickle.load(model_file)
