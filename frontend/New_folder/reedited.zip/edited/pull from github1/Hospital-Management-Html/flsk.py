from flask import Flask,render_template,request
import pickle
import numpy as np
app = Flask(__name__)

model=pickle.load(open('model.pkl', 'rb'))
@app.route('/')
def hello_world():  # put application's code here
    return 'Hello World!'

@app.route('/predict', methods=['POST','GET'])
def predict():
    if request.method == 'POST':
        # Your form processing logic here
        int_features = [int(x) for x in request.form.values()]
        final = [np.array(int_features)]
        print(int_features)
        print(final)
        prediction = model.predict(final)
        output = True if prediction > 0 else False
        if output:
            return render_template('result.html', message="There is a chance of Autism!!!!! Please consider consulting our doctors.")
        else:
            return render_template('result.html', message="You do not or might have other issues!!!!! Please go through the following website.")
    else:
        # Handle the GET request (if needed)
        return render_template('formpage.html')  # You can render the form page again

if __name__ == '__main__':
    app.run()

