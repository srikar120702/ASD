from flask import Flask,render_template,request
import pickle
import numpy as np
app = Flask(__name__)

model=pickle.load(open('SVM.pkl','rb'))
@app.route('/')
def hello_world():  # put application's code here
    return 'Hello World!'

@app.route('/predict')
def predict():
    print(request.form)
    int_features=[int(x) for x in request.form.values()]
    final=[np.array(int_features)]
    print(int_features)
    print(final)
    prediction=model.predict(final)
    output= True if prediction>0 else False
    if output==True:
        return render_template('''There is a chance of Autism!!!!!
                                  please consider consulting our doctors.''')
    else:
        return render_template('''You do not or might have other issues!!!!!
                                  please go though the following website.''')

if __name__ == '__main__':
    app.run()

